### Crud de Empregado em DDD
- Utilizado .Net 6
- Testes Unitários com xUnit e Moq
- Design Patterns - Padrão Repositorio.  
