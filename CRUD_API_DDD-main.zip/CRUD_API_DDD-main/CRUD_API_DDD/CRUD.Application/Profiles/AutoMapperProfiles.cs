﻿using AutoMapper;

namespace CRUD.Application.Profiles
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
        }
    }
}
