﻿namespace CRUD.Application.Interfaces
{
    public interface IRabbitMQ
    {
        void Add();
    }
}
